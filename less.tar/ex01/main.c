#include <stdio.h>
#include <string.h>

int ft_strncmp(char *s1, char *s2, unsigned int n); 

int main (int argc, char *argv[])
{
  printf ("strncmp> %d\n", strncmp("aaa", "aaa", 3));
  printf ("ft_strncmp> %d\n", ft_strncmp("aaa", "aaa", 3));
  putchar('\n');

  printf ("strncmp> %d\n", strncmp("aaa", "aa", 3));
  printf ("ft_strncmp> %d\n", ft_strncmp("aaa", "aa", 3));
  putchar('\n');

  printf ("strncmp> %d\n", strncmp("aab", "aaa", 3));
  printf ("ft_strncmp> %d\n", ft_strncmp("aab", "aaa", 3));
  putchar('\n');

  printf ("strncmp> %d\n", strncmp("aab", "aaa", 2));
  printf ("ft_strncmp> %d\n", ft_strncmp("aab", "aaa", 2));
  putchar('\n');

  printf ("strncmp> %d\n", strncmp("aca", "aca", 3));
  printf ("ft_strncmp> %d\n", ft_strncmp("aca", "aca", 3));
  putchar('\n');

  printf ("strncmp> %d\n", strncmp("bala", "abelha", 3));
  printf ("ft_strncmp> %d\n", ft_strncmp("bala", "abelha", 3));
  putchar('\n');
  
  printf ("strncmp> %d\n", strncmp("bala", "abelha", 1));
  printf ("ft_strncmp> %d\n", ft_strncmp("bala", "abelha", 1));
  putchar('\n');

  return 0;
}
