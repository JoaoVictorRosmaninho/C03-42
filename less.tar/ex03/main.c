#include <stdio.h>
#include <string.h>

char *ft_strncat(char *dest, char *src, unsigned int nb); 

int main(void) {
  char nome[20]  = "joao"; 

  printf("ft_strncat: %s\n", ft_strncat(nome, " victor", 5));
  printf("strncat: %s\n", strncat(nome, " victor", 3));
}
