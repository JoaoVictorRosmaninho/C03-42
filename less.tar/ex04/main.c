#include <stdio.h>
#include <string.h>

char *ft_strstr(char *str, char *to_find);
unsigned int	ft_strlen(char *str);

int main(void) {
  printf("ft_strstr: %s\n", ft_strstr("teste", "ste"));
  printf("strstr: %s\n", strstr("teste", "ste"));
  
  printf("ft_strstr: %s\n", ft_strstr("145689", "5"));
  printf("strstr: %s\n", strstr("145689", "5"));
  
  printf("ft_strstr: %s\n", ft_strstr("testeletrasasas", "l"));
  printf("strstr: %s\n", strstr("testeletrasasas", "l"));
  printf("ft_strstr: %s\n", ft_strstr("1234567855-521", "-5"));
  printf("strstr: %s\n", strstr("1234567855-521", "-5"));

  printf("ft_strstr: %s\n", ft_strstr("1234567855-521testeSrinfg", "rin"));
  printf("strstr: %s\n", strstr("1234567855-521testeSrinfg", "rin"));

  printf("ft_strstr: %s\n", ft_strstr("1234567855-521testeSrinfg", "srin"));
  printf("strstr: %s\n", strstr("1234567855-521testeSrinfg", "srin"));

  return 0;
}
