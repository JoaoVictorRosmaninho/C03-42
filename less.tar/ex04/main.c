#include <stdio.h>
#include <string.h>

char *ft_strstr(char *str, char *to_find);

int main(void) {
  printf("ft_strstr: %s\n", ft_strstr("teste", "ste"));
  printf("strstr: %s\n", strstr("teste", "ste"));
  return 0;
}
