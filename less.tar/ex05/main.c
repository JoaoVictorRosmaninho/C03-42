#include <stdio.h>
#include <bsd/bsd.h>
#include <string.h>

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size);
unsigned int	ft_strlcat2(char *dest, char *src, unsigned int size);
unsigned int	ft_strlcat3(char *dest, char *src, unsigned int size);

int main(void) {
  char name[30]  = "joao";
  char name2[30] = "joao";
  char name3[30] = "joao";
  char name4[30] = "joao";
  
  unsigned int size; 
  unsigned int size2;
  unsigned int size3;
  unsigned int size4;


  size  =  ft_strlcat(name, "victor", 30);
  size2 = strlcat(name2, "victor", 30);
  size3 =  ft_strlcat2(name3, "victor", 30);
  size4 =  ft_strlcat2(name4, "victor", 30);

  printf("ft_strlcat: %s => size: %d\n", name, size);
  printf("strlcat   : %s => size: %d\n", name2, size2);
  printf("ft_strlcat2: %s => size: %d\n", name3, size3);
  printf("ft_strlcat3: %s => size: %d\n", name4, size4);

  putchar('\n');
  size  =  ft_strlcat(name, "victor", 10);
  size2  =  strlcat(name2, "victor", 10);
  size3 =  ft_strlcat2(name3, "victor", 10);
  size4 =  ft_strlcat2(name4, "victor", 10);

  printf("ft_strlcat: %s => size: %d\n", name, size);
  printf("strlcat   : %s => size: %d\n", name2, size2);
  printf("ft_strlcat2: %s => size: %d\n", name3, size3);
  printf("ft_strlcat3: %s => size: %d\n", name4, size4);

  putchar('\n');
  size  =  ft_strlcat(name, "victor", 3);
  size2  =  strlcat(name2, "victor", 3);
  size3 =  ft_strlcat2(name3, "victor", 3);
  size4 =  ft_strlcat2(name4, "victor", 3);

  printf("ft_strlcat: %s => size: %d\n", name, size);
  printf("strlcat   : %s => size: %d\n", name2, size2);
  printf("ft_strlcat2: %s => size: %d\n", name3, size3);
  printf("ft_strlcat3: %s => size: %d\n", name4, size4);


  putchar('\n');
  size =  ft_strlcat(name, "victor",1);
  size2 =  strlcat(name2, "victor", 1);
  size3 =  ft_strlcat2(name3, "victor", 1);
  size4 =  ft_strlcat2(name4, "victor", 1);

  printf("ft_strlcat: %s => size: %d\n", name, size);
  printf("strlcat   : %s => size: %d\n", name2, size2);
  printf("ft_strlcat2: %s => size: %d\n", name3, size3);
  printf("ft_strlcat3: %s => size: %d\n", name4, size4);


  putchar('\n');

  size =  ft_strlcat(name, "victor", 6);
  size2 =  strlcat(name2, "victor", 6);
  size3 =  ft_strlcat2(name3, "victor", 6);
  size4 =  ft_strlcat2(name4, "victor", 6);

  printf("ft_strlcat: %s => size: %d\n", name, size);
  printf("strlcat   : %s => size: %d\n", name2, size2);
  printf("ft_strlcat2: %s => size: %d\n", name3, size3); 
  printf("ft_strlcat3: %s => size: %d\n", name4, size4);

  putchar('\n');
  size =   ft_strlcat(name, "victor", 10);
  size2 =  strlcat(name2, "victor", 10);
  size3 =  ft_strlcat2(name3, "victor", 10);
  size4 =  ft_strlcat2(name4, "victor", 10);

  printf("ft_strlcat: %s => size: %d\n", name, size);
  printf("strlcat   : %s => size: %d\n", name2, size2);
  printf("ft_strlcat2: %s => size: %d\n", name3, size3);
  printf("ft_strlcat3: %s => size: %d\n", name4, size4);

}
