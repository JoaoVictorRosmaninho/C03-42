#include <stdio.h>
#include <bsd/bsd.h>



int main(void) {
  char name[10] = "joao";
  char name2[10] = "joao";

  printf("%s => size: %d\n", name, size);


  printf("%s => size: %d\n", name2, size);

}
