unsigned int    ft_strlcat3(char *dest, char *src, unsigned int size)
{
    unsigned int    i;
    unsigned int    s_len;
    unsigned int    d_len;

    s_len = 0;
    while (src[s_len])
        s_len++;
    d_len = 0;
    while (dest[d_len])
        d_len++;
    if (size == 0)
        return (s_len);
    i = 0;
    while ((src[i] != 0) && (d_len + i) < (size -1))
    {
        dest[d_len + i] = src[i];
        i++;
    }
    if (i < size)
        dest[d_len + i] = '\0';
    if (d_len > size)
        return (s_len + size);
    return (d_len + s_len);
}
