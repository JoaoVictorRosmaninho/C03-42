#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int	ft_strcmp(char *s1, char *s2);

int	main(void)
{
  printf("%d\n", strcmp("aaa", "aaa"));
  printf("%d\n", ft_strcmp("aaa", "aaa"));
}

